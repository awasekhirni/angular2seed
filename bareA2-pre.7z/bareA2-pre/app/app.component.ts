import {Component} from '@angular/core';

@Component({
    selector:'syed-app',
    templateUrl:`app/app.component.html`,
    styleUrls:['app/app.component.css']

})

export class AppComponent {
    msg=' Welcome Syed-- Angular 2 Demo Page';
}