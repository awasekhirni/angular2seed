
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';

@NgModule({
    //importing the browse module and dependencies
    imports:      [ BrowserModule ],
    // declaring your components here 
  declarations: [ AppComponent ],
    //bootstrapping your component/ root component
    bootstrap:    [ AppComponent ]

})

export class AppModule{ }